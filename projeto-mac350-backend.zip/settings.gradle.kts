rootProject.name = "com.projeto350.projeto-mac350-backend"
